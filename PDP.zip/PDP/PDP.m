%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%                                                                     %%%
%%%   Paper: Fundamentals of Wobbling and Hardware Impairments-Aware    %%%
%%%          Air-to-Ground Channel Model                                %%%
%%%   Authors: Morteza Banagar, Harpreet S. Dhillon                     %%%
%%%   Emails: mbanagar@vt.edu, hdhillon@vt.edu                          %%%
%%%                                                                     %%%
%%%   This code is used to generate Fig. 2 of this paper, PDP for       %%%
%%%   ideal and impaired hardware scenarios                             %%%
%%%                                                                     %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

K = 11.5;
N = 20;
omega_0 = deg2rad(20);
beta = 1;
P_alpha_1 = 1 / (2 * pi) * (2 - exp(-omega_0 / beta) - exp(-(pi / 2 - omega_0) / beta));
P_alpha_0 = N * K * P_alpha_1;
d_0 = 300;
c = 3e8;
tau_0 = d_0 / c;
rho_i = unifrnd(1e7, 1e8, [N, 1]);
kappa_chi_T2 = 0.5;
kappa_chi_R2 = 0.5;
P_L_T = 0.5;
P_L_R = 0.5;
Q_T_st = 5;
Q_T_en = 15;
Q_R_st = 5;
Q_R_en = 15;

t_vec = [20, 50] * 1e-3;
num_t = length(t_vec);
tau_vec = tau_0 * (2 : 0.2 : 3);
num_tau = length(tau_vec);
PDP_NoHI = zeros(num_tau + 1, 1);
PDP_NonSt = zeros(num_tau + 1, num_t);
PDP_WSS = zeros(num_tau + 1, 1);

PDP_NoHI(1) = P_alpha_0;
i_tau = 1;
for tau = tau_vec
    i_tau = i_tau + 1;
    PDP_NoHI(i_tau) = P_alpha_1 * sum(rho_i .* exp(-rho_i * (tau - tau_0)));
end

i_t = 0;
for t = t_vec
    i_t = i_t + 1;
    PDP_NonSt(1, i_t) = P_alpha_0 * P_L_R * P_L_T *...
        integral(@(q) 1 / (Q_R_en - Q_R_st) * sin(2 * pi * q * t) .^ 2, Q_R_st, Q_R_en) *...
        integral(@(q) 1 / (Q_T_en - Q_T_st) * sin(2 * pi * q * (t - tau_0)) .^ 2, Q_T_st, Q_T_en);
end
PDP_WSS(1) = P_alpha_0 * kappa_chi_R2 * kappa_chi_T2;
i_tau = 1;
i_t = 0;
for tau = tau_vec
    i_tau = i_tau + 1;
    for t = t_vec
        i_t = i_t + 1;
        PDP_NonSt(i_tau, i_t) = P_alpha_1 * P_L_R * P_L_T *...
            integral(@(q) 1 / (Q_R_en - Q_R_st) * sin(2 * pi * q * t) .^ 2, Q_R_st, Q_R_en) *...
            integral(@(q) 1 / (Q_T_en - Q_T_st) * sin(2 * pi * q * (t - tau)) .^ 2, Q_T_st, Q_T_en) *...
            sum(rho_i .* exp(-rho_i * (tau - tau_0)));
    end
    i_t = 0;
    PDP_WSS(i_tau) = P_alpha_1 * kappa_chi_R2 * kappa_chi_T2 *...
        sum(rho_i .* exp(-rho_i * (tau - tau_0)));
end

figure(101)
bar([tau_0, tau_vec] * 1e6, pow2db([PDP_NoHI, PDP_WSS, PDP_NonSt]) + 80, 'LineWidth', 2)
grid on
box on
xlabel('$\tau ~(\mu{\rm s})$', 'Interpreter', 'latex')
ylabel('$P_{\rm c}(\tau; t)$', 'Interpreter', 'latex')
yticks(0 : 20 : 100)
yticklabels({'-80 dB', '-60 dB', '-40 dB', '-20 dB', '0 dB', '20 dB'})
legend({'No HI'; 'WSS HI'; 'NonSt HI ($t = 20$ ms)'; 'NonSt HI ($t = 50$ ms)'}, 'Location', 'northeast', 'FontSize', 12, 'Interpreter', 'latex')
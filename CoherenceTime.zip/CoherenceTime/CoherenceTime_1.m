%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%                                                                     %%%
%%%   Paper: Fundamentals of Wobbling and Hardware Impairments-Aware    %%%
%%%          Air-to-Ground Channel Model                                %%%
%%%   Authors: Morteza Banagar, Harpreet S. Dhillon                     %%%
%%%   Emails: mbanagar@vt.edu, hdhillon@vt.edu                          %%%
%%%                                                                     %%%
%%%   This code is used to generate Fig. 3 of this paper, coherence     %%%
%%%   time: Normalized channel ACF for different random processes       %%%
%%%                                                                     %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

K = 11.5;
N = 20;
omega_0 = deg2rad(20);
beta = 1;
P_alpha_1 = 1 / (2 * pi) * (2 - exp(-omega_0 / beta) - exp(-(pi / 2 - omega_0) / beta));
P_alpha_0 = N * K * P_alpha_1;
c = 3e8;
f_c = 6e9;
lambda = c / f_c;
y_D = 40; % [cm]
y_D = y_D / 100;
theta_m = deg2rad(5);
Q_st = 5;
Q_en = 25;
l_chi_T = 0.05;
l_chi_R = 0.05;

t_vec = [0, 20, 50] * 1e-3;
num_t = length(t_vec);
del_t_vec = 0 : 1e-4 : 1e-1;
num_del_t = length(del_t_vec);
ACF_CT_WSS = zeros(num_del_t, num_t);
G_0_NonSI = zeros(num_del_t, num_t);
G_1_NonSI = zeros(num_del_t, num_t);
ACF_CT_WSS_SI = zeros(num_del_t, 1);
G_0_SI = zeros(num_del_t, 1);
G_1_SI = zeros(num_del_t, 1);
i_del_t = 0;
i_t = 0;
for del_t = del_t_vec
    i_del_t = i_del_t + 1;
    if mod(i_del_t - 1, 100) == 0
        disp(['Delta t = ', num2str(del_t)])
    end
    for t = t_vec
        i_t = i_t + 1;
        G_0_NonSI(i_del_t, i_t) = 2 * P_alpha_0 * integral(@(q) 1 / (Q_en - Q_st) * sinc(2 / lambda * theta_m * y_D * cos(omega_0) * (sin(2 * pi * q * (t + del_t)) - sin(2 * pi * q * t))), Q_st, Q_en);
        G_1_NonSI(i_del_t, i_t) = integral2(@(omega_i, q) 1 / (Q_en - Q_st) / (pi * beta) * exp(-abs(omega_i - omega_0) / beta) .* sinc(2 / lambda * theta_m * y_D * cos(omega_i) .* (sin(2 * pi * q * (t + del_t)) - sin(2 * pi * q * t))), 0, pi / 2, Q_st, Q_en);
        ACF_CT_WSS(i_del_t, i_t) = exp(-(1 / (2 * l_chi_R ^ 2) + 1 / (2 * l_chi_T ^ 2)) * del_t ^ 2) *...
            (G_0_NonSI(i_del_t, i_t) + N * G_1_NonSI(i_del_t, i_t)) / (2 * N * (K + 1) * P_alpha_1);
    end
    i_t = 0;
    G_0_SI(i_del_t) = 2 * P_alpha_0 * exp(-2 * pi ^ 2 / lambda ^ 2 * y_D ^ 2 * cos(omega_0) ^ 2 * del_t);
    G_1_SI(i_del_t) = integral(@(omega_i) 1 / (pi * beta) * exp(-abs(omega_i - omega_0) / beta) .* exp(-2 * pi ^ 2 / lambda ^ 2 * y_D ^ 2 * cos(omega_i) .^ 2 * del_t), 0, pi / 2);
    ACF_CT_WSS_SI(i_del_t) = exp(-(1 / (2 * l_chi_R ^ 2) + 1 / (2 * l_chi_T ^ 2)) * del_t ^ 2) *...
        (G_0_SI(i_del_t) + N * G_1_SI(i_del_t)) / (2 * N * (K + 1) * P_alpha_1);
end

figure(201)
hold on
grid on
box on
plot(del_t_vec * 1e3, ACF_CT_WSS_SI, 'LineWidth', 2)
plot(del_t_vec * 1e3, ACF_CT_WSS, 'LineWidth', 2, 'LineStyle', '--')
xlabel('$\Delta t ~({\rm ms})$', 'Interpreter', 'latex')
ylabel('Normalized $A_{\rm C}(t, \Delta t)$', 'Interpreter', 'latex')
ylim([-0.1, 1])
legend({'Wiener Process'; 'Sinusoidal Process ($t = 0$ ms)'; 'Sinusoidal Process ($t = 20$ ms)'; 'Sinusoidal Process ($t = 50$ ms)'}, 'Location', 'northeast', 'FontSize', 12, 'Interpreter', 'latex')
hold off
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%                                                                     %%%
%%%   Paper: Fundamentals of Wobbling and Hardware Impairments-Aware    %%%
%%%          Air-to-Ground Channel Model                                %%%
%%%   Authors: Morteza Banagar, Harpreet S. Dhillon                     %%%
%%%   Emails: mbanagar@vt.edu, hdhillon@vt.edu                          %%%
%%%                                                                     %%%
%%%   This code is used to generate Fig. 6 of this paper, coherence     %%%
%%%   time: Normalized channel ACF for different theta_m                %%%
%%%                                                                     %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

K = 11.5;
N = 20;
omega_0 = deg2rad(20);
beta = 1;
P_alpha_1 = 1 / (2 * pi) * (2 - exp(-omega_0 / beta) - exp(-(pi / 2 - omega_0) / beta));
P_alpha_0 = N * K * P_alpha_1;
c = 3e8;
f_c = 2.4e9;
lambda = c / f_c;
y_D = 40; % [cm]
y_D = y_D / 100;
theta_m = deg2rad([5, 7, 10]);
num_theta_m = length(theta_m);
Q_st = 5;
Q_en = 25;
l_chi_T = 0.05;
l_chi_R = 0.05;

del_t_vec = 0 : 1e-4 : 1e-1;
num_del_t = length(del_t_vec);
ACF_CT_WSS = zeros(num_del_t, num_theta_m);
G_0_NonSI = zeros(num_del_t, num_theta_m);
G_1_NonSI = zeros(num_del_t, num_theta_m);
i_del_t = 0;
t = 0;
for del_t = del_t_vec
    i_del_t = i_del_t + 1;
    if mod(i_del_t - 1, 100) == 0
        disp(['Delta t = ', num2str(del_t)])
    end
    for i_theta_m = 1 : num_theta_m
        G_0_NonSI(i_del_t, i_theta_m) = 2 * P_alpha_0 * integral(@(q) 1 / (Q_en - Q_st) * sinc(2 / lambda * theta_m(i_theta_m) * y_D * cos(omega_0) * (sin(2 * pi * q * (t + del_t)) - sin(2 * pi * q * t))), Q_st, Q_en);
        G_1_NonSI(i_del_t, i_theta_m) = integral2(@(omega_i, q) 1 / (Q_en - Q_st) / (pi * beta) * exp(-abs(omega_i - omega_0) / beta) .* sinc(2 / lambda * theta_m(i_theta_m) * y_D * cos(omega_i) .* (sin(2 * pi * q * (t + del_t)) - sin(2 * pi * q * t))), 0, pi / 2, Q_st, Q_en);
        ACF_CT_WSS(i_del_t, i_theta_m) = exp(-(1 / (2 * l_chi_R ^ 2) + 1 / (2 * l_chi_T ^ 2)) * del_t ^ 2) *...
            (G_0_NonSI(i_del_t, i_theta_m) + N * G_1_NonSI(i_del_t, i_theta_m)) / (2 * N * (K + 1) * P_alpha_1);
    end
end

figure(204)
hold on
grid on
box on
plot(del_t_vec * 1e3, ACF_CT_WSS(:, 1), 'LineWidth', 2, 'LineStyle', ':')
plot(del_t_vec * 1e3, ACF_CT_WSS(:, 2), 'LineWidth', 2, 'LineStyle', '--')
plot(del_t_vec * 1e3, ACF_CT_WSS(:, 3), 'LineWidth', 2)
xlabel('$\Delta t ~({\rm ms})$', 'Interpreter', 'latex')
ylabel('Normalized $A_{\rm C}(0, \Delta t)$', 'Interpreter', 'latex')
ylim([-0.1, 1])
hold off
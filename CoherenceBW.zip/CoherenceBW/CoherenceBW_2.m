%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%                                                                     %%%
%%%   Paper: Fundamentals of Wobbling and Hardware Impairments-Aware    %%%
%%%          Air-to-Ground Channel Model                                %%%
%%%   Authors: Morteza Banagar, Harpreet S. Dhillon                     %%%
%%%   Emails: mbanagar@vt.edu, hdhillon@vt.edu                          %%%
%%%                                                                     %%%
%%%   This code is used to generate Fig. 8 of this paper, coherence     %%%
%%%   bandwidth: Normalized channel ACF for different Rician K factors  %%%
%%%                                                                     %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

K_vec = [0, 1, 5, 11.5];
num_K = length(K_vec);
N = 20;
rho_i = unifrnd(1e7, 1e8, [N, 1]);

del_f_vec = [0 : 1e4 : 1e6, 1e6 + 1e5 : 1e5 : 1e8];
num_del_f = length(del_f_vec);
ACF_CB_WSS = zeros(num_del_f, num_K);
i_del_f = 0;
i_K = 0;
for del_f = del_f_vec
    i_del_f = i_del_f + 1;
    for K = K_vec
        i_K = i_K + 1;
        ACF_CB_WSS(i_del_f, i_K) = abs(K + 1 / N * sum(rho_i ./ (rho_i + 1j * 2 * pi * del_f))) / (K + 1);
    end
    i_K = 0;
end

figure(302)
plot(del_f_vec / 1e6, ACF_CB_WSS, 'LineWidth', 2)
grid on
box on
xlabel('$\Delta f ~({\rm MHz})$', 'Interpreter', 'latex')
ylabel('Normalized $A_{\rm C}(\Delta f; 0)$', 'Interpreter', 'latex')
ylim([0, 1])
These codes generate Figs. 7 and 8 of [1].

Please cite [1] if you reuse any part of these codes.

[1] M. Banagar and H. S. Dhillon, “Fundamentals of wobbling and hardware impairments-aware air-to-ground channel model”, available online: https://arxiv.org/abs/2205.10957
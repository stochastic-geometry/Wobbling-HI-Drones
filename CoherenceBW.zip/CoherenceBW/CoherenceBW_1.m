%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%                                                                     %%%
%%%   Paper: Fundamentals of Wobbling and Hardware Impairments-Aware    %%%
%%%          Air-to-Ground Channel Model                                %%%
%%%   Authors: Morteza Banagar, Harpreet S. Dhillon                     %%%
%%%   Emails: mbanagar@vt.edu, hdhillon@vt.edu                          %%%
%%%                                                                     %%%
%%%   This code is used to generate Fig. 7 of this paper, coherence     %%%
%%%   bandwidth: Normalized channel ACF for different impairment        %%%
%%%   models and times t                                                %%%
%%%                                                                     %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

K = 11.5;
N = 20;
d_0 = 300;
c = 3e8;
tau_0 = d_0 / c;
rho_i = unifrnd(1e7, 1e8, [N, 1]);
Q_T_st = 5;
Q_T_en = 15;

t_vec = [1, 2, 4] * tau_0;
num_t = length(t_vec);
del_f_vec = [0 : 1e4 : 1e6, 1e6 + 1e5 : 1e5 : 1e8];
num_del_f = length(del_f_vec);
ACF_CB_NonSt = zeros(num_del_f, num_t);
ACF_CB_WSS = zeros(num_del_f, 1);
H_i = zeros(num_del_f, num_t, N);
H_0 = zeros(1, num_t);
i_del_f = 0;
i_t = 0;
for del_f = del_f_vec
    i_del_f = i_del_f + 1;
    if mod(i_del_f - 1, 100) == 0
        disp(['Delta f = ', num2str(del_f / 1e3), ' kHz'])
    end
    for t = t_vec
        i_t = i_t + 1;
        H_0(i_t) = N * K * integral(@(q) 1 / (Q_T_en - Q_T_st) * sin(2 * pi * q * (t - tau_0)) .^ 2, Q_T_st, Q_T_en);
        for i = 1 : N
            H_i(i_del_f, i_t, i) = rho_i(i) / (2 * (rho_i(i) + 1j * 2 * pi * del_f)) -...
                integral(@(q) 1 / (Q_T_en - Q_T_st) * (...
                rho_i(i) * exp(1j * 4 * pi * q * (t - tau_0)) ./ (4 * (rho_i(i) + 1j * 2 * pi * del_f + 1j * 4 * pi * q)) +...
                rho_i(i) * exp(-1j * 4 * pi * q * (t - tau_0)) ./ (4 * (rho_i(i) + 1j * 2 * pi * del_f - 1j * 4 * pi * q))...
                ), Q_T_st, Q_T_en);
        end
        ACF_CB_NonSt(i_del_f, i_t) = abs(H_0(i_t) + sum(H_i(i_del_f, i_t, :)));
    end
    i_t = 0;
    ACF_CB_WSS(i_del_f) = abs(K + 1 / N * sum(rho_i ./ (rho_i + 1j * 2 * pi * del_f))) / (K + 1);
end
ACF_CB_NonSt = ACF_CB_NonSt ./ max(ACF_CB_NonSt, [], 1);

figure(301)
plot(del_f_vec / 1e6, ACF_CB_WSS, 'LineWidth', 2)
hold on
grid on
box on
plot(del_f_vec / 1e6, ACF_CB_NonSt(:, 1), 'LineWidth', 2, 'LineStyle', '--')
plot(del_f_vec / 1e6, ACF_CB_NonSt(:, 2), 'LineWidth', 2, 'LineStyle', '-.')
plot(del_f_vec / 1e6, ACF_CB_NonSt(:, 3), 'LineWidth', 2, 'LineStyle', ':')
xlabel('$\Delta f ~({\rm MHz})$', 'Interpreter', 'latex')
ylabel('Normalized $A_{\rm C}(\Delta f; t)$', 'Interpreter', 'latex')
ylim([0, 1])
legend({'WSS HI'; 'NonSt HI ($t = \tau_0$)'; 'NonSt HI ($t = 2\tau_0$)'; 'NonSt HI ($t = 4\tau_0$)'}, 'Location', 'southeast', 'FontSize', 12, 'Interpreter', 'latex')
hold off
p = get(gca, 'Position');
h = axes('Parent', gcf, 'Position', [p(1) + 0.3, p(2) + 0.35, p(3) - 0.5, p(4) - 0.5]);
plot(h, del_f_vec / 1e6, ACF_CB_WSS, 'LineWidth', 2)
hold on
grid on
box on
plot(h, del_f_vec / 1e6, ACF_CB_NonSt(:, 1), 'LineWidth', 2, 'LineStyle', '--')
plot(h, del_f_vec / 1e6, ACF_CB_NonSt(:, 2), 'LineWidth', 2, 'LineStyle', '-.')
plot(h, del_f_vec / 1e6, ACF_CB_NonSt(:, 3), 'LineWidth', 2, 'LineStyle', ':')
set(h, 'Xlim', [0, inf], 'Ylim', [0.92, 0.96])
set(h, 'XTick', 0 : 20 : 100)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%                                                                     %%%
%%%   Paper: Fundamentals of Wobbling and Hardware Impairments-Aware    %%%
%%%          Air-to-Ground Channel Model                                %%%
%%%   Authors: Morteza Banagar, Harpreet S. Dhillon                     %%%
%%%   Emails: mbanagar@vt.edu, hdhillon@vt.edu                          %%%
%%%                                                                     %%%
%%%   This code is used to generate Figs. 9 and 10 of this paper, PSD   %%%
%%%   of n(t) for different impairment levels (Wiener and sinusoidal    %%%
%%%   wobbling models)                                                  %%%
%%%                                                                     %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

K = 11.5;
N = 20;
omega_0 = deg2rad(20);
beta = 1;
P_alpha_1 = 1 / (2 * pi) * (2 - exp(-omega_0 / beta) - exp(-(pi / 2 - omega_0) / beta));
P_alpha_0 = N * K * P_alpha_1;
c = 3e8;
f_c = 2.4e9;
lambda = c / f_c;
y_D = 40; % [cm]
y_D = y_D / 100;
u = sqrt(2) * pi / lambda * y_D;
theta_m = deg2rad(5);
Q_st = 5;
Q_en = 25;
kappa_eta_T2_vec = [0.1, 0.1, 0.5];
kappa_eta_R2_vec = [0.1, 0.1, 0.5];
kappa_chi_R2_vec = [0.1, 0.1, 0.5];
kappa2_vec = kappa_chi_R2_vec .* kappa_eta_T2_vec;
num_kappa = length(kappa_eta_T2_vec);
l_eta_T_vec = [0.01, 0.05, 0.01];
l_eta_R_vec = [0.01, 0.05, 0.01];
l_chi_R_vec = [0.01, 0.05, 0.01];
l_vec = 1 ./ sqrt(l_chi_R_vec .^ (-2) + l_eta_T_vec .^ (-2));
N_0 = 1e-8;

f_vec = -200 : 1 : 200;
num_f = length(f_vec);
f_int_1 = zeros(num_kappa, num_f);
f_int_3 = zeros(num_kappa, num_f);
f_int_4 = zeros(num_kappa, num_f);
S_n_WSS_SI = zeros(num_kappa, num_f);
S_n_WSS = zeros(num_kappa, num_f);
max_iter = 1e6;
t_max = 100;
del_t_max = 2;
q_max = Q_en - Q_st;
omega_i_max = pi / 2;
for i_kappa = 1 : num_kappa
    i_f = 0;
    tic
    for f = f_vec
        i_f = i_f + 1;
        if mod(i_f - 1, 10) == 0
            disp(['f = ', num2str(f), ' Hz'])
        end
        f_int_1(i_kappa, i_f) = integral(@(omega_i) 1 / (pi * beta) * exp(-abs(omega_i - omega_0) / beta) .*...
            exp(1 / 2 * l_vec(i_kappa) ^ 2 * u ^ 4 * cos(omega_i) .^ 4) .*...
            exp(1j * 2 * pi * l_vec(i_kappa) ^ 2 * u ^ 2 * cos(omega_i) .^ 2 * f), 0, pi / 2);
        fun3 = 0;
        fun4 = 0;
        parfor k = 1 : max_iter
            t = rand * t_max;
            del_t = rand * del_t_max - del_t_max / 2;
            q = rand * q_max + Q_st;
            omega_i = rand * omega_i_max;
            fun3 = fun3 + 1 / (Q_en - Q_st) * kappa2_vec(i_kappa) * exp(-del_t ^ 2 / (2 * l_vec(i_kappa) ^ 2)) *...
                sinc(2 / lambda * theta_m * y_D * cos(omega_0) * (sin(2 * pi * q * (t + del_t)) - sin(2 * pi * q * t))) *...
                exp(-1j * 2 * pi * f * del_t);
            fun4 = fun4 + 1 / (Q_en - Q_st) * kappa2_vec(i_kappa) * exp(-del_t .^ 2 / (2 * l_vec(i_kappa) ^ 2)) * 1 / (pi * beta) * exp(-abs(omega_i - omega_0) / beta) *...
                sinc(2 / lambda * theta_m * y_D * cos(omega_i) * (sin(2 * pi * q * (t + del_t)) - sin(2 * pi * q * t))) *...
                exp(-1j * 2 * pi * f * del_t);
        end
        f_int_3(i_kappa, i_f) = t_max * del_t_max * q_max * fun3 / max_iter;
        f_int_4(i_kappa, i_f) = t_max * del_t_max * q_max * omega_i_max * fun4 / max_iter;
    end
    toc
    S_n_WSS_SI(i_kappa, :) = N_0 / 2 + kappa_eta_R2_vec(i_kappa) * sqrt(2 * pi * l_eta_R_vec(i_kappa) ^ 2) * exp(-2 * pi ^ 2 * l_eta_R_vec(i_kappa) ^ 2 * f_vec .^ 2) +...
        kappa2_vec(i_kappa) * sqrt(2 * pi * l_vec(i_kappa) ^ 2) * exp(-2 * pi ^ 2 * l_vec(i_kappa) ^ 2 * f_vec .^ 2) .*...
        (2 * P_alpha_0 * exp(1 / 2 * l_vec(i_kappa) ^ 2 * u ^ 4 * cos(omega_0) ^ 4) * exp(1j * 2 * pi * l_vec(i_kappa) ^ 2 * u ^ 2 * cos(omega_0) ^ 2 * f_vec) + N * f_int_1(i_kappa, :));
    S_n_WSS(i_kappa, :) = N_0 / 2 + kappa_eta_R2_vec(i_kappa) * sqrt(2 * pi * l_eta_R_vec(i_kappa) ^ 2) * exp(-2 * pi ^ 2 * l_eta_R_vec(i_kappa) ^ 2 * f_vec .^ 2) +...
        2 * P_alpha_0 / t_max * f_int_3(i_kappa, :) + N / t_max * f_int_4(i_kappa, :);
end

figure(401)
plot(f_vec, pow2db(abs(S_n_WSS_SI(1, :))), 'LineWidth', 2, 'LineStyle', '--')
hold on
grid on
box on
plot(f_vec, pow2db(abs(S_n_WSS_SI(2, :))), 'LineWidth', 2)
plot(f_vec, pow2db(abs(S_n_WSS_SI(3, :))), 'LineWidth', 2, 'LineStyle', ':')
xlabel('$f ~({\rm Hz})$', 'Interpreter', 'latex')
ylabel('$S_n^{\rm WSS-SI}$ (dB)', 'Interpreter', 'latex')
ylim([-140, 80])
legend({'$l_{\eta_{\rm T}} = l_{\eta_{\rm R}} = l_{\chi_{\rm R}} = 0.01, \kappa_{\eta_{\rm T}}^2 = \kappa_{\eta_{\rm R}}^2 = \kappa_{\chi_{\rm R}}^2 = 0.1$';...
    '$l_{\eta_{\rm T}} = l_{\eta_{\rm R}} = l_{\chi_{\rm R}} = 0.05, \kappa_{\eta_{\rm T}}^2 = \kappa_{\eta_{\rm R}}^2 = \kappa_{\chi_{\rm R}}^2 = 0.1$';...
    '$l_{\eta_{\rm T}} = l_{\eta_{\rm R}} = l_{\chi_{\rm R}} = 0.01, \kappa_{\eta_{\rm T}}^2 = \kappa_{\eta_{\rm R}}^2 = \kappa_{\chi_{\rm R}}^2 = 0.5$'}, 'Location', 'southeast', 'FontSize', 12, 'Interpreter', 'latex')
hold off

figure(402)
plot(f_vec, pow2db(abs(S_n_WSS(1, :))), 'LineWidth', 2, 'LineStyle', '--')
hold on
grid on
box on
plot(f_vec, pow2db(abs(S_n_WSS(2, :))), 'LineWidth', 2)
plot(f_vec, pow2db(abs(S_n_WSS(3, :))), 'LineWidth', 2, 'LineStyle', ':')
xlabel('$f ~({\rm Hz})$', 'Interpreter', 'latex')
ylabel('$S_n^{\rm WSS}$ (dB)', 'Interpreter', 'latex')
legend({'$l_{\eta_{\rm T}} = l_{\eta_{\rm R}} = l_{\chi_{\rm R}} = 0.01, \kappa_{\eta_{\rm T}}^2 = \kappa_{\eta_{\rm R}}^2 = \kappa_{\chi_{\rm R}}^2 = 0.1$';...
    '$l_{\eta_{\rm T}} = l_{\eta_{\rm R}} = l_{\chi_{\rm R}} = 0.05, \kappa_{\eta_{\rm T}}^2 = \kappa_{\eta_{\rm R}}^2 = \kappa_{\chi_{\rm R}}^2 = 0.1$';...
    '$l_{\eta_{\rm T}} = l_{\eta_{\rm R}} = l_{\chi_{\rm R}} = 0.01, \kappa_{\eta_{\rm T}}^2 = \kappa_{\eta_{\rm R}}^2 = \kappa_{\chi_{\rm R}}^2 = 0.5$'}, 'Location', 'southeast', 'FontSize', 12, 'Interpreter', 'latex')
hold off